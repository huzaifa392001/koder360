<div class="sidebar">
    <div class="menuBtn">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </div>
    <div class="socialList">
        <a href="" target="_blank">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="" target="_blank">
            <i class="fab fa-twitter"></i>
        </a>
        <a href="" target="_blank">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="" target="_blank">
            <i class="fab fa-linkedin-in"></i>
        </a>
    </div>
</div>