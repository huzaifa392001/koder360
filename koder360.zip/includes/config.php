<?php
$SITE_NAME = 'koder360.com';
$SITE_NAME_TEXT = 'Koder360';
$PHONE_NUMBER_TEL = '+16478947312';
$PHONE_NUMBER = ' +1 (647) 894-7312';
$PHONE_NUMBER_PK_TEL = '+923212813730';
$PHONE_NUMBER_PK = '+92 (321) 281-3730';
$PHONE_NUMBER_USA_TEL = '+12062037424';
$PHONE_NUMBER_USA = '+1 (206) 203-7424';
$ADDRESS = 'Toronto, Ontario M2N 0E9';
$ADDRESS_PK = 'Plot # 3/29 Union council Road  no 15 Maqboolabad M-C-H-S, Karachi';
$ADDRESS_USA = 'Wyoming, 30 N GOULD ST STE R';

$EMAIL = 'info@koder360.com';
define('BASE_URL', 'https://koder360.com/');
