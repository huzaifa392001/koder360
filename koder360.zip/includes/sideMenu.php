<div class="sidebar">
    <div class="menuBtn">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </div>
    <div class="socialList">
        <a href="https://www.facebook.com/profile.php?id=61565091697173" target="_blank">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="https://www.instagram.com/koder360x/" target="_blank">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="https://www.linkedin.com/company/koder-360" target="_blank">
            <i class="fab fa-linkedin-in"></i>
        </a>
    </div>
</div>