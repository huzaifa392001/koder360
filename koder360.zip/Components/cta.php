<div class="ctaBanner">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-xl-7 col-md-10">
                <h3 class="subHeading">
                    <?php echo isset($subHeading) ? $subHeading : 'WORK WITH US'; ?>
                </h3>
                <h2>
                    <?php echo isset($mainHeading) ? $mainHeading : 'Let’s work together to build something great'; ?>
                </h2>
                <a class="themeBtn" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal"> Get Started
                    <span></span><span></span><span></span><span></span> <b class="blinking-dot"></b></a>
            </div>
        </div>
    </div>
</div>
